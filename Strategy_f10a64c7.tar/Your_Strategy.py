import datetime
import reference.EmergencyCode as EmergencyCode
import json


Interval=[{'begin':datetime.time(3),'end':datetime.time(5,30)},{'begin':datetime.time(6,30)},{'end':datetime.time(2,30)}]
#介於3:00~5:30或超過6:30或不到2:30

Threshold=10
#當函式處理訊息的速度慢於接收訊息的速度時，會導致訊息累積。此數值代表當超過多少時將會顯示警告。如果沒有填表示永遠不警告。

#使用client.StrategyLogger紀錄的log檔名為Strategy.[時間].log

def Strategy(client,message,datatype):#請注意 這一行請不要更動
    #只有在時間使用者定義的時間區間內收到資料才會運作
    client.StrategyLogger.info('Strategy-可記錄info等級')#目前只會紀錄info等級以上，其餘等級參考python logging levels
    
    #訊號格式
    signal=dict(
        Symbol='TW0002330008',
        Trend=True,
        Position=True,
        Daily=True,
        Price=700,
        Quantity=1,
        Validity=datetime.datetime(2021,3,25,13).isoformat() or datetime.datetime(2021,3,25,13).timestamp()
        )

    #送訊號
    client.SendSignal(signal)


    
def DataProcess(client,message,datatype):#請注意 這個函式如果不需要用可以整個刪除但若要使用的話名稱及參數請不要更動
    #只要收到任何資料DataProcess都會運作，且會在Strategy前運行
    client.StrategyLogger.info('DataProcess-可記錄info等級')#目前只會紀錄info等級以上，其餘等級參考python logging levels
    indicators={'my_indicators_1':1,'my_indicators_2':-1}
    #可以return自訂的指標數值，返回值將會被記錄成csv檔
    return indicators

    

def Emergency(client,message,datatype):#請注意 這個函式如果不需要用可以整個刪除但若要使用的話名稱及參數請不要更動
    #此函數負責緊急狀況處理，當收到來自於Emergency/[ErrorType]這個topic的訊息時會啟動
    ErrorType=message.split('/')[1]
    
    DetailErrorType=getattr(EmergencyCode,ErrorType)(message.payload)
    #e.g.
    #if ErrorType='Tick' and message.payload=0
    #DetailErrorType=EmergencyCode.Tick(0)
    #DetailErrorType.name='TickRecovered'

    client.StrategyLogger.info('可記錄error等級')#目前只會紀錄info等級以上，其餘等級參考python logging levels