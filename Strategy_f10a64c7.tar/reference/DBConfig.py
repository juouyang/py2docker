import enum

HOST='192.168.233.116'
PORT=1433
SERVER_NAME='AISQL'
USERNAME='sqltest'
PASSWORD='tel476724'


class InsertDataBaseCode(enum.IntEnum):
    Successfully=0
    Error=1