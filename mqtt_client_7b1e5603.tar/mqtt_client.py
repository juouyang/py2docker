import socket
import struct
from json import dumps

import paho.mqtt.client as mqtt

from .functions.client import *


class mqttclient(mqtt.Client):
    def __init__(self,client_id,userdata=None):
        self._published={}
        self._subscribed={}
        self._unsubscribed={}
        self._unsubscribe_subscribe_mid={}
        self._Topics=None
        self._lock=None
        return super().__init__(client_id=client_id, clean_session=True, userdata=userdata, protocol=mqtt.MQTTv311)


    def _send_subscribe(self, dup, topics, properties=None):
        #Overrided method
        remaining_length = 2
        if self._protocol == mqtt.MQTTv5:
            if properties == None:
                packed_subscribe_properties = b'\x00'
            else:
                packed_subscribe_properties = properties.pack()
            remaining_length += len(packed_subscribe_properties)
        for t, _ in topics:
            remaining_length += 2 + len(t) + 1

        command = mqtt.SUBSCRIBE | (dup << 3) | 0x2
        packet = bytearray()
        packet.append(command)
        self._pack_remaining_length(packet, remaining_length)
        local_mid = self._mid_generate()
        packet.extend(struct.pack("!H", local_mid))

        if self._protocol == mqtt.MQTTv5:
            packet += packed_subscribe_properties

        for t, q in topics:
            self._pack_str16(packet, t)
            if self._protocol == mqtt.MQTTv5:
                packet += q.pack()
            else:
                packet.append(q)

        return (self._packet_queue(command, packet, local_mid, 1), local_mid)


    def _send_unsubscribe(self, dup, topics, properties=None):
        #Overrided method
        remaining_length = 2
        if self._protocol == mqtt.MQTTv5:
            if properties == None:
                packed_unsubscribe_properties = b'\x00'
            else:
                packed_unsubscribe_properties = properties.pack()
            remaining_length += len(packed_unsubscribe_properties)
        for t in topics:
            remaining_length += 2 + len(t)

        command = mqtt.UNSUBSCRIBE | (dup << 3) | 0x2
        packet = bytearray()
        packet.append(command)
        self._pack_remaining_length(packet, remaining_length)
        local_mid = self._mid_generate()
        packet.extend(struct.pack("!H", local_mid))

        if self._protocol == mqtt.MQTTv5:
            packet += packed_unsubscribe_properties

        for t in topics:
            self._pack_str16(packet, t)

        return (self._packet_queue(command, packet, local_mid, 1), local_mid)


    def _send_publish(self, mid, topic, payload=b'', qos=0, retain=False, dup=False, info=None, properties=None):
        #Overrided method
        assert not isinstance(topic, mqtt.unicode) and not isinstance(
            payload, mqtt.unicode) and payload is not None

        if self._sock is None:
            return mqtt.MQTT_ERR_NO_CONN

        command = mqtt.PUBLISH | ((dup & 0x1) << 3) | (qos << 1) | retain
        packet = bytearray()
        packet.append(command)

        payloadlen = len(payload)
        remaining_length = 2 + len(topic) + payloadlen

        if qos > 0:
            remaining_length += 2

        if self._protocol == mqtt.MQTTv5:
            if properties == None:
                packed_properties = b'\x00'
            else:
                packed_properties = properties.pack()
            remaining_length += len(packed_properties)

        self._pack_remaining_length(packet, remaining_length)
        self._pack_str16(packet, topic)

        if qos > 0:
            packet.extend(struct.pack("!H", mid))

        if self._protocol == mqtt.MQTTv5:
            packet.extend(packed_properties)

        packet.extend(payload)

        return self._packet_queue(mqtt.PUBLISH, packet, mid, qos, info)


    def connect(self, host=os.environ.get('MQTT_IP','192.168.233.134'), port=int(os.environ.get('MQTT_PORT',1883)), keepalive=60, bind_address='', bind_port=0, clean_start=mqtt.MQTT_CLEAN_START_FIRST_ONLY, properties=None):
        #Overrided method
        if self.on_connect is None:
            self.on_connect=basic_on_connect
        else:
            self._external_on_connect=self.on_connect
            self.on_connect=on_connect

        if self.on_subscribe is None:
            self.on_subscribe=basic_on_subscribe
        else:
            self._external_on_subscribe=self.on_subscribe
            self.on_subscribe=on_subscribe

        if self.on_disconnect is None:
            self.on_disconnect=basic_on_disconnect
        else:
            self._external_on_disconnect=self.on_disconnect
            self.on_disconnect=on_disconnect

        if self.on_unsubscribe is None:
            self.on_unsubscribe=basic_on_unsubscribe
        else:
            self._external_on_unsubscribe=self.on_unsubscribe
            self.on_unsubscribe=on_unsubscribe

        return super().connect(host, port=port, keepalive=keepalive, bind_address=bind_address, bind_port=bind_port, clean_start=clean_start, properties=properties)
    

    def disconnect(self, reasoncode=None, properties=None):
        #Overrided method
        self.publish(f'events/client_connecting/{self._client_id.decode()}',payload=-time.time(),qos=2,retain=True)
        self.publish(f'events/session_subscribing/{self._client_id.decode()}',None,qos=2,retain=True)

        self._state = mqtt.mqtt_cs_disconnecting

        if self._sock is None:
            return mqtt.MQTT_ERR_NO_CONN

        return self._send_disconnect(reasoncode, properties)


    def should_exit(self):
        return self._state==mqtt.mqtt_cs_disconnecting or self._thread_terminate is True

    
    def loop_forever(self, timeout=1.0, max_packets=1, retry_first_connection=False):
        #Overrided method
        while True:
            if self._thread_terminate is True:
                break

            if self._state==mqtt.mqtt_cs_connect_async:
                try:
                    self.reconnect()
                except (socket.error,OSError,mqtt.WebsocketConnectionError):
                    if not mqtt.retry_first_connection:
                        raise
                    self._easy_log(mqtt.MQTT_LOG_INFO,"Connection failed, retrying")
                    self._reconnect_wait()
            else:
                break

        while True:
            while self.loop(timeout,max_packets)==mqtt.MQTT_ERR_SUCCESS:
                if (self._thread_terminate is True
                    and self._current_out_packet is None
                    and len(self._out_packet)==0
                        and len(self._out_messages)==0):
                    return 1

            if (self._thread_terminate is True
                and self._current_out_packet is None
                and len(self._out_packet)==0
                    and len(self._out_messages)==0):
                return 1

            if self.should_exit():
                break
            else:
                self._reconnect_wait()
                if self.should_exit():
                    break
                else:
                    try:
                        self.reconnect()
                    except (socket.error,OSError,mqtt.WebsocketConnectionError):
                        self._easy_log(mqtt.MQTT_LOG_INFO,"Connection failed, retrying")


    def run(self):
        if self._state==mqtt.mqtt_cs_connect_async:
            self._reconnect_wait()
            self.reconnect()
        else:
            self.connect()

        self.loop_forever()
        

    def run_until(self,*args):
        now_=datetime.datetime.now(datetime.timezone(datetime.timedelta(seconds=-time.timezone)))
        deadline=[]
        for a in args:
            if isinstance(a,datetime.datetime):
                if a>now_:
                    deadline.append(a.timestamp())
                else:
                    raise ValueError('時間設定錯誤')
                
            elif isinstance(a,datetime.time):
                if not a.tzinfo:
                    a=now_.replace(hour=a.hour,minute=a.minute,second=a.second,microsecond=a.microsecond)
                else:
                    a=now_.astimezone(tz=a.tzinfo).replace(hour=a.hour,minute=a.minute,second=a.second,microsecond=a.microsecond)
                
                diff=(a-now_).total_seconds()
                if diff>0:
                    deadline.append(a.timestamp())
                else:
                    deadline.append(86400+a.timestamp())
            else:
                now_=now_.timestamp()
                if a>now_:
                    deadline.append(a-now_)
                else:
                    raise ValueError('時間設定錯誤')

        deadline=min(deadline)
        if self._state==mqtt.mqtt_cs_connect_async:
            self._reconnect_wait()
            self.reconnect()
        else:
            self.connect()
        while time.time()<deadline:
            if self._thread_terminate is True:
                break

            if self._state==mqtt.mqtt_cs_connect_async:
                try:
                    self.reconnect()
                except (socket.error,OSError,mqtt.WebsocketConnectionError):
                    if not mqtt.retry_first_connection:
                        raise
                    self._easy_log(mqtt.MQTT_LOG_INFO,"Connection failed, retrying")
                    self._reconnect_wait()
            else:
                break

        while time.time()<deadline:
            while self.loop()==mqtt.MQTT_ERR_SUCCESS and time.time()<deadline:
                if (self._thread_terminate is True
                    and self._current_out_packet is None
                    and len(self._out_packet)==0
                        and len(self._out_messages)==0):
                    self.publish(f'events/session_subscribing/{self._client_id.decode()}',None,qos=2,retain=True)
                    self.disconnect()
                    return 1

            if (self._thread_terminate is True
                and self._current_out_packet is None
                and len(self._out_packet)==0
                    and len(self._out_messages)==0):
                self.publish(f'events/session_subscribing/{self._client_id.decode()}',None,qos=2,retain=True)
                self.disconnect()
                return 1

            if self.should_exit():
                break
            else:
                self._reconnect_wait()
                if self.should_exit():
                    break
                else:
                    try:
                        self.reconnect()
                    except (socket.error,OSError,mqtt.WebsocketConnectionError):
                        self._easy_log(mqtt.MQTT_LOG_INFO,"Connection failed, retrying")

        self.publish(f'events/session_subscribing/{self._client_id.decode()}',None,qos=2,retain=True)
        self.disconnect()


    @property
    def run_strategy(self):
        return self._run_strategy

    @run_strategy.setter
    def run_strategy(self,func):
        self._run_strategy=func


    def SendSignal(self,signal):
        token=self._client_id.decode().split('-')[-1]
        if isinstance(signal,dict):
            signal=dumps(signal)

        for i in range(5):
            rc,mid=self.publish(f'Strategy/{token}',signal,qos=2,retain=True)
            if rc==0:
                self._published[mid]=signal
                break
            else:
                #失敗處理?
                self._logger.error(f'message:{signal} publish failed with rc={rc}, retries={i}')
                time.sleep(0.1)


    def InsertDataBase(self,table,signal):
        temp=[self._client_id.decode(),signal]
        mid,rc=self.publish(f'InsertDataBase/{table}',dumps(temp),qos=2)


def client_settings(client,Topics,Path):
    log_path=os.path.join(Path,'logs')
    if not os.path.exists(log_path):
        os.mkdir(log_path)
    client._Topics=Topics
    client._Path=Path
    logger=logging.getLogger('MQTT')
    logger.setLevel(logging.INFO)
    file_handler=handlers.TimedRotatingFileHandler(os.path.join(log_path,f'MQTTLog({os.getpid()})'),when='midnight')
    file_handler.suffix+='.log'
    file_handler.setFormatter(format)
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    client.enable_logger(logger)

    for b in basicsubscription:
        client.message_callback_add(f"MQTTClient/{client._client_id.decode()}/{b.replace('_','/')}",eval(b))
    for b,func in specialsubscription:
        client.message_callback_add(b,func)

    client.will_set(f'events/client_connecting/{client._client_id.decode()}',-1,qos=2,retain=True)

    return client


def Client(ClientId,Path,Topics=None,UserData=None):
    client=mqttclient(client_id=ClientId,userdata=UserData)
    return client_settings(client,Topics,Path)