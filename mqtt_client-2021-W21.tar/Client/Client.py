def Client(ClientId,Path,Strategy=None,DataProcess=None,Emergency=None,Topics=None,UserData=None):
    import paho.mqtt.client as mqtt
    from json import loads,dumps
    import datetime
    import time
    import socket
    import struct
    import os
    import logging
    import logging.handlers as handlers
    import pandas as pd

    basicsubscription=[
        'Modify_Subscription',
        'Modify_UpdateUserData',
        'Modify_ModifyUserData',
        'Terminate',
        'PingPong'
        ]

    specialsubscription={
        }


    class FakeClient:
        signal=[]
        def SendSignal(self,signal):
            self.signal.append(signal)


    def BasicSubscrbe(client,userdata,flags,rc):
        client.publish(f'events/client_connecting/{client._client_id.decode()}',time.time(),qos=2,retain=True)
        client._logger.info(f'connected')
        for b in basicsubscription:
            client.subscribe(f"MQTTClient/{client._client_id.decode()}/{b.replace('_','/')}",2)
        for b in specialsubscription:
            client.subscribe(b,2)

        if client._subscribed:
            for mid,topics in client._subscribed.items():
                pass
            client._subscribed={client.subscribe(list(TopicGenerator(eval(topics))))[1]:topics}
        elif Topics:
            client._subscribed={client.subscribe(list(TopicGenerator(Topics)))[1]:str(Topics)}
        else:
            client.publish(f'events/session_subscribing/{client._client_id.decode()}',None,qos=2,retain=True)


    def on_connect(client,userdata,flags,rc):
        client._Costom_on_connect(client,userdata,flags,rc)
        BasicSubscrbe(client,userdata,flags,rc)
        

    def on_subscribe(client,userdata,mid,granted_qos,properties=None):
        if mid in client._subscribed:
            client._logger.info(f'subscribed topics:\n{client._subscribed[mid]}')
            for mid,topics in client._subscribed.items():
                pass
            client.publish(f'events/session_subscribing/{client._client_id.decode()}',topics,qos=2,retain=True)
            

    def on_unsubscribe(client,userdata,mid):
        if mid in client._unsubscribed:
            client._logger.info(f'unsubscribed topics:\n{client._subscribed[client._unsubscribe_subscribe_mid[mid]]}')
            del client._subscribed[client._unsubscribe_subscribe_mid[mid]]
            del client._unsubscribe_subscribe_mid[mid]
            del client._unsubscribed[mid]
            

    def check_time(client,message,datatype):
        if client._fake_client.begin_time or client._fake_client.end_time:
            now_=datetime.datetime.now().time()#datetime.timezone.utc).time()
            for i,b in enumerate(client._fake_client.begin_time):
                if (not b or now_>b) and (not client._fake_client.end_time[i] or now_<client._fake_client.end_time[i]):
                    client._algorithm(client._fake_client,client._userdata,message,datatype)
                    break
        else:
            client._algorithm(client._fake_client,client._userdata,message,datatype)

        for signal in client._fake_client.signal:
            client.SendSignal(signal)
            client._fake_client.signal=[]


    def on_message_without_data_process(client,userdata,message):
        if 'BACK_TEST' in os.environ:
            payload=loads(message.payload)
            datatype=payload.pop('datatype')
            check_time(client,dumps(payload),datatype)
        else:
            check_time(client,message.payload,message.topic)


    def on_message_with_data_process(client,userdata,message):
        if 'BACK_TEST' in os.environ:
            payload=loads(message.payload)
            datatype=payload.pop('datatype')
            payload=dumps(payload)
            DataProcess(client._fake_client,userdata,payload,datatype)
            check_time(client,payload,datatype)
        else:
            DataProcess(client._fake_client,userdata,message.payload,message.topic)
            check_time(client,message.payload,message.topic)


    def on_publish(client,userdata,mid):
        if mid in client._published:
            del client._published[mid]
            if client._published:
                client._logger.info(f'Queueing message:{client._published}')
            else:
                client._logger.info('No queueing message')


    def on_disconnect(client,userdata,rc):
        client._logger.info(f'disconnected with rc={rc}')


    def on_log(client,userdata,level,buf):
        pass


    class mqttclient(mqtt.Client):
        _published={}
        _subscribed={}
        _unsubscribed={}
        _unsubscribe_subscribe_mid={}
        def __init__(self,client_id,userdata,clean_session=True,protocol=mqtt.MQTTv311):
            return super().__init__(client_id=client_id, clean_session=clean_session, userdata=userdata, protocol=protocol)


        def _send_subscribe(self, dup, topics, properties=None):
            #Overrided method
            remaining_length = 2
            if self._protocol == mqtt.MQTTv5:
                if properties == None:
                    packed_subscribe_properties = b'\x00'
                else:
                    packed_subscribe_properties = properties.pack()
                remaining_length += len(packed_subscribe_properties)
            for t, _ in topics:
                remaining_length += 2 + len(t) + 1

            command = mqtt.SUBSCRIBE | (dup << 3) | 0x2
            packet = bytearray()
            packet.append(command)
            self._pack_remaining_length(packet, remaining_length)
            local_mid = self._mid_generate()
            packet.extend(struct.pack("!H", local_mid))

            if self._protocol == mqtt.MQTTv5:
                packet += packed_subscribe_properties

            for t, q in topics:
                self._pack_str16(packet, t)
                if self._protocol == mqtt.MQTTv5:
                    packet += q.pack()
                else:
                    packet.append(q)

            return (self._packet_queue(command, packet, local_mid, 1), local_mid)


        def _send_unsubscribe(self, dup, topics, properties=None):
            remaining_length = 2
            if self._protocol == mqtt.MQTTv5:
                if properties == None:
                    packed_unsubscribe_properties = b'\x00'
                else:
                    packed_unsubscribe_properties = properties.pack()
                remaining_length += len(packed_unsubscribe_properties)
            for t in topics:
                remaining_length += 2 + len(t)

            command = mqtt.UNSUBSCRIBE | (dup << 3) | 0x2
            packet = bytearray()
            packet.append(command)
            self._pack_remaining_length(packet, remaining_length)
            local_mid = self._mid_generate()
            packet.extend(struct.pack("!H", local_mid))

            if self._protocol == mqtt.MQTTv5:
                packet += packed_unsubscribe_properties

            for t in topics:
                self._pack_str16(packet, t)

            return (self._packet_queue(command, packet, local_mid, 1), local_mid)


        def _send_publish(self, mid, topic, payload=b'', qos=0, retain=False, dup=False, info=None, properties=None):
            #Overrided method
            assert not isinstance(topic, mqtt.unicode) and not isinstance(
                payload, mqtt.unicode) and payload is not None

            if self._sock is None:
                return mqtt.MQTT_ERR_NO_CONN

            command = mqtt.PUBLISH | ((dup & 0x1) << 3) | (qos << 1) | retain
            packet = bytearray()
            packet.append(command)

            payloadlen = len(payload)
            remaining_length = 2 + len(topic) + payloadlen

            if qos > 0:
                remaining_length += 2

            if self._protocol == mqtt.MQTTv5:
                if properties == None:
                    packed_properties = b'\x00'
                else:
                    packed_properties = properties.pack()
                remaining_length += len(packed_properties)

            self._pack_remaining_length(packet, remaining_length)
            self._pack_str16(packet, topic)

            if qos > 0:
                packet.extend(struct.pack("!H", mid))

            if self._protocol == mqtt.MQTTv5:
                packet.extend(packed_properties)

            packet.extend(payload)

            return self._packet_queue(mqtt.PUBLISH, packet, mid, qos, info)


        def connect(self, host=os.environ.get('MQTT_IP','192.168.233.134'), port=int(os.environ.get('MQTT_PORT',1883)), keepalive=60, bind_address='', bind_port=0, clean_start=mqtt.MQTT_CLEAN_START_FIRST_ONLY, properties=None):
            #Overrided method
            if self._on_connect is None:
                self.on_connect=BasicSubscrbe
            else:
                self._Costom_on_connect=self._on_connect
                self.on_connect=on_connect

            return super().connect(host, port=port, keepalive=keepalive, bind_address=bind_address, bind_port=bind_port, clean_start=clean_start, properties=properties)
        

        def disconnect(self, reasoncode=None, properties=None):
            #Overrided method
            self.publish(f'events/client_connecting/{self._client_id.decode()}',payload=-time.time(),qos=2,retain=True)
            self.publish(f'events/session_subscribing/{self._client_id.decode()}',None,qos=2,retain=True)

            self._state = mqtt.mqtt_cs_disconnecting

            if self._sock is None:
                return mqtt.MQTT_ERR_NO_CONN

            return self._send_disconnect(reasoncode, properties)


        def should_exit(self):
            return self._state==mqtt.mqtt_cs_disconnecting or self._thread_terminate is True

        
        def loop_forever(self, timeout=1.0, max_packets=1, retry_first_connection=False):
            #Overrided method
            while True:
                if self._thread_terminate is True:
                    break

                if self._state==mqtt.mqtt_cs_connect_async:
                    try:
                        self.reconnect()
                    except (socket.error,OSError,mqtt.WebsocketConnectionError):
                        if not mqtt.retry_first_connection:
                            raise
                        self._easy_log(mqtt.MQTT_LOG_INFO,"Connection failed, retrying")
                        self._reconnect_wait()
                else:
                    break

            while True:
                while self.loop(timeout,max_packets)==mqtt.MQTT_ERR_SUCCESS:
                    if (self._thread_terminate is True
                        and self._current_out_packet is None
                        and len(self._out_packet)==0
                            and len(self._out_messages)==0):
                        return 1

                if (self._thread_terminate is True
                    and self._current_out_packet is None
                    and len(self._out_packet)==0
                        and len(self._out_messages)==0):
                    return 1

                if self.should_exit():
                    break
                else:
                    self._reconnect_wait()
                    if self.should_exit():
                        break
                    else:
                        try:
                            self.reconnect()
                        except (socket.error,OSError,mqtt.WebsocketConnectionError):
                            self._easy_log(mqtt.MQTT_LOG_INFO,"Connection failed, retrying")


        def run(self,intervals={}):
            if Strategy:
                self._fake_client.begin_time,self._fake_client.end_time=intervals_process(intervals)
            self.connect()
            self.loop_forever()


        def run_until(self,*args):
            now_=datetime.datetime.now(datetime.timezone(datetime.timedelta(seconds=-time.timezone)))
            deadline=[]
            for a in args:
                if isinstance(a,datetime.datetime):
                    if a>now_:
                        deadline.append(a.timestamp())
                    else:
                        raise ValueError('時間設定錯誤')
                    
                elif isinstance(a,datetime.time):
                    if not a.tzinfo:
                        a=now_.replace(hour=a.hour,minute=a.minute,second=a.second,microsecond=a.microsecond)
                    else:
                        a=now_.astimezone(tz=a.tzinfo).replace(hour=a.hour,minute=a.minute,second=a.second,microsecond=a.microsecond)
                    
                    diff=(a-now_).total_seconds()
                    if diff>0:
                        deadline.append(a.timestamp())
                    else:
                        deadline.append(86400+a.timestamp())
                else:
                    now_=now_.timestamp()
                    if a>now_:
                        deadline.append(a-now_)
                    else:
                        raise ValueError('時間設定錯誤')

            deadline=min(deadline)
            self.connect()
            while time.time()<deadline:
                if self._thread_terminate is True:
                    break

                if self._state==mqtt.mqtt_cs_connect_async:
                    try:
                        self.reconnect()
                    except (socket.error,OSError,mqtt.WebsocketConnectionError):
                        if not mqtt.retry_first_connection:
                            raise
                        self._easy_log(mqtt.MQTT_LOG_INFO,"Connection failed, retrying")
                        self._reconnect_wait()
                else:
                    break

            while time.time()<deadline:
                while self.loop()==mqtt.MQTT_ERR_SUCCESS and time.time()<deadline:
                    if (self._thread_terminate is True
                        and self._current_out_packet is None
                        and len(self._out_packet)==0
                            and len(self._out_messages)==0):
                        self.publish(f'events/session_subscribing/{self._client_id.decode()}',None,qos=2,retain=True)
                        self.disconnect()
                        return 1

                if (self._thread_terminate is True
                    and self._current_out_packet is None
                    and len(self._out_packet)==0
                        and len(self._out_messages)==0):
                    self.publish(f'events/session_subscribing/{self._client_id.decode()}',None,qos=2,retain=True)
                    self.disconnect()
                    return 1

                if self.should_exit():
                    break
                else:
                    self._reconnect_wait()
                    if self.should_exit():
                        break
                    else:
                        try:
                            self.reconnect()
                        except (socket.error,OSError,mqtt.WebsocketConnectionError):
                            self._easy_log(mqtt.MQTT_LOG_INFO,"Connection failed, retrying")

            self.publish(f'events/session_subscribing/{self._client_id.decode()}',None,qos=2,retain=True)
            self.disconnect()


        def SendSignal(self,signal):
            token=self._client_id.decode().split('-')[-1]
            self._logger.info(f"Sending signal to {token}:\n{signal}")
            if isinstance(signal,dict):
                signal=dumps(signal)

            for i in range(5):
                rc,mid=self.publish(f'Strategy/{token}',signal,qos=2,retain=True)
                if rc==0:
                    self._published[mid]=signal
                    break
                else:
                    #失敗處理?
                    self._logger.error(f'message:{signal} publish failed with rc={rc}, retries={i}')
                    time.sleep(0.1)


        def InsertDataBase(self,table,signal):
            temp=[self._client_id.decode(),signal]
            mid,rc=self.publish(f'InsertDataBase/{table}',dumps(temp),qos=2)


        def PostSignal(self,SID,signal):
            pass


    def intervals_process(intervals):
        begin_time=[]
        end_time=[]
        if isinstance(intervals,dict):
            intervals_process_ind(intervals,begin_time,end_time)

        else:
            for interval in intervals:
                intervals_process_ind(interval,begin_time,end_time)

        return begin_time,end_time


    def intervals_process_ind(interval,begin_time,end_time):
        temp=tuple(interval.keys())
        for key in temp:
            interval[key.lower()]=interval.pop(key)
        begin_time.append(interval.get('begin'))
        end_time.append(interval.get('end'))
        if begin_time[-1] and end_time[-1] and begin_time[-1]>end_time[-1]:
            raise ValueError('時間設定錯誤，結束時間大於起始時間')


    def TopicGenerator(Topics):
        if 'BACK_TEST' in os.environ:
            for t in Topics:
                yield f'{t}/backtest',2
        else:
            for t in Topics:
                yield t,2
    

    def Modify_Subscription(client,userdata,message):
        if message.payload:
            print(f'message.payload={message.payload}')
            payload=eval(message.payload)
            print(f'eval(message.payload)={eval(message.payload)}')
            temp=tuple(client._subscribed.items())
            print(f'tuple(client._subscribed.items())={tuple(client._subscribed.items())}')
            for mid,subscribed in temp:
                unsubscribe_mid=client.unsubscribe(eval(subscribed))[1]
                print(f'client.unsubscribe(eval(subscribed))[1]={unsubscribe_mid}')
                client._unsubscribed[unsubscribe_mid]=subscribed
                client._unsubscribe_subscribe_mid[unsubscribe_mid]=mid

            print(f'list(TopicGenerator(payload))={list(TopicGenerator(payload))}')
            client._subscribed[client.subscribe(list(TopicGenerator(payload)))[1]]=message.payload.decode()


    def Modify_UpdateUserData(client,userdata,message):
        if message.payload:
            payload=loads(message.payload)
            client._userdata.update(payload)
            client._logger.info(f'Updated userdata:\n{payload}')


    def Modify_ModifyUserData(client,userdata,message):
        if message.payload:
            try:
                client._userdata=eval(message.payload)
            except:
                client._userdata=message.payload
            client._logger.info(f'Modified userdata:\n{client._userdata}')


    def Terminate(client,userdata,message):
        client.disconnect()
        client._logger.info(f'Terminated:{time.time()}')


    def PingPong(client,userdata,message):
        client.publish(f'{message.topic}/r',True,qos=2)


    def EmergencyProcess(client,userdata,message):
        Emergency(client._fake_client,userdata,message.payload,message.topic)



    log_path=os.path.join(Path,'logs')
    if not os.path.exists(log_path):
        os.mkdir(log_path)
    format=logging.Formatter('%(asctime)s %(levelname)s：\n%(message)s')
    console_handler=logging.StreamHandler()
    console_handler.setFormatter(format)
    
    if Strategy:
        client=mqttclient(client_id=ClientId,userdata=UserData)
        StrategyLogger=logging.getLogger('StrategyLogger')
        StrategyLogger.setLevel(logging.INFO)
        file_handler=handlers.TimedRotatingFileHandler(os.path.join(log_path,'StrategyLog'),when='midnight')
        file_handler.suffix+='.log'
        file_handler.setFormatter(format)
        StrategyLogger.addHandler(console_handler)
        StrategyLogger.addHandler(file_handler)
        client._fake_client=FakeClient(StrategyLogger)
        client.on_publish=on_publish
        folders=set(('logs','__pycache__'))
        for reference in os.listdir(Path):
            if reference not in folders and '.' not in reference:
                break
        TDQSymbol=set(pd.read_csv(os.path.join(Path,reference,'TDQSymbol.csv'))['ISIN'])
        for topic in Topics:
            row=None
            for ISIN in topic.split('/'):
                if ISIN in TDQSymbol:
                    row=True
                    break
            if row is None:
                continue
                #raise ValueError(f'topic:{topic}，DB內無此ISIN，請檢查Topics')
        
        client._algorithm=Strategy
        if DataProcess:
            client.on_message=on_message_with_data_process
        else:
            client.on_message=on_message_without_data_process

        if Emergency:
            client.message_callback_add(f"Emergency/#",EmergencyProcess)

    elif DataProcess or Emergency:
        raise Exception('沒有Strategy')

    else:
        client=mqttclient(client_id=ClientId,userdata=UserData)

    logger=logging.getLogger('MQTT')
    logger.setLevel(logging.INFO)
    file_handler=handlers.TimedRotatingFileHandler(os.path.join(log_path,f'MQTTLog({os.getpid()})'),when='midnight')
    file_handler.suffix+='.log'
    file_handler.setFormatter(format)
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    client.enable_logger(logger)
    client.on_disconnect=on_disconnect
    client.on_log=on_log
    client.on_subscribe=on_subscribe
    client.on_unsubscribe=on_unsubscribe

    for b in basicsubscription:
        client.message_callback_add(f"MQTTClient/{ClientId}/{b.replace('_','/')}",eval(b))
    for b,func in specialsubscription:
        client.message_callback_add(b,func)

    client.will_set(f'events/client_connecting/{ClientId}',-1,qos=2,retain=True)

    return client