import datetime
import logging
import logging.handlers as handlers
import os
import time
from json import loads

basicsubscription=[
    'Modify_Subscription',
    'Modify_UpdateUserData',
    'Modify_ModifyUserData',
    'Terminate',
    'PingPong'
    ]

specialsubscription={}

format=logging.Formatter('%(asctime)s %(levelname)s：\n%(message)s')
console_handler=logging.StreamHandler()
console_handler.setFormatter(format)


class Variables:
    def __init__(self,Variables):
        self.__dict__.update(Variables)

    def __getattr__(self,key):
        return self.__dict__[key]

    def __delattr__(self,key):
        if key in self.__dict__:
            del self.__dict__[key]

    def __setattr__(self,key,value):
        self.__dict__[key]=value

    def __getitem__(self,key):
        return self.__dict__[key]

    def __setitem__(self,key,value):
        self.__dict__[key]=value

    def __delitem__(self,key):
        if key in self.__dict__:
            del self.__dict__[key]
        

class FakeClient:
    signal=[]
    def __init__(self,StrategyLogger,ClientId,variables):
        self.StrategyLogger=StrategyLogger
        self.ClientId=ClientId
        self.Variables=Variables(variables)


    def SendSignal(self,signal):
        self.signal.append(signal)


def on_message_settings(ClientId,Path,intervals,Strategy,Variables):
    StrategyLogger=logging.getLogger('StrategyLogger')
    StrategyLogger.setLevel(logging.INFO)
    file_handler=handlers.TimedRotatingFileHandler(os.path.join(Path,'logs','StrategyLog'),when='midnight')
    file_handler.suffix+='.log'
    file_handler.setFormatter(format)
    StrategyLogger.addHandler(console_handler)
    StrategyLogger.addHandler(file_handler)
    fake_client=FakeClient(StrategyLogger,ClientId,Variables)
    fake_client.begin_time,fake_client.end_time=intervals_process(intervals)
    fake_client._external_on_message=Strategy

    return fake_client,{},[]


def basic_on_connect(client,userdata,flags,rc):
    client.publish(f'events/client_connecting/{client._client_id.decode()}',time.time(),qos=2,retain=True)
    if client._logger:
        client._logger.info(f'connected')
    for b in basicsubscription:
        client.subscribe(f"MQTTClient/{client._client_id.decode()}/{b.replace('_','/')}",2)
    for b in specialsubscription:
        client.subscribe(b,2)

    if client._subscribed:
        for mid,topics in client._subscribed.items():
            pass
        client._subscribed={client.subscribe(list(TopicGenerator(eval(topics))))[1]:topics}
    elif client._Topics:
        client._subscribed={client.subscribe(list(TopicGenerator(client._Topics)))[1]:str(client._Topics)}
    else:
        client.publish(f'events/session_subscribing/{client._client_id.decode()}',None,qos=2,retain=True)


def on_connect(client,userdata,flags,rc):
    client._external_on_connect(client,userdata,flags,rc)
    basic_on_connect(client,userdata,flags,rc)


def basic_on_disconnect(client,userdata,rc):
    if client._logger:
        client._logger.info(f'disconnected with rc={rc}')

    
def on_disconnect(client,userdata,rc):
    client._external_on_disconnect(client,userdata,rc)
    basic_on_disconnect(client,userdata,rc)


def basic_on_subscribe(client,userdata,mid,granted_qos,properties=None):
    if mid in client._subscribed:
        if client._logger:
            client._logger.info(f'subscribed topics:\n{client._subscribed[mid]}')
        for mid,topics in client._subscribed.items():
            pass
        client.publish(f'events/session_subscribing/{client._client_id.decode()}',topics,qos=2,retain=True)


def on_subscribe(client,userdata,mid,granted_qos,properties=None):
    client._external_on_subscribe(client,userdata,mid,granted_qos)
    basic_on_subscribe(client,userdata,mid,granted_qos)
    

def basic_on_unsubscribe(client,userdata,mid):
    if mid in client._unsubscribed:
        if client._logger:
            client._logger.info(f'unsubscribed topics:\n{client._subscribed[client._unsubscribe_subscribe_mid[mid]]}')
        del client._subscribed[client._unsubscribe_subscribe_mid[mid]]
        del client._unsubscribe_subscribe_mid[mid]
        del client._unsubscribed[mid]
        

def on_unsubscribe(client,userdata,mid):
    client._external_on_unsubscribe(client,userdata,mid)
    basic_on_unsubscribe(client,userdata,mid)
    

def on_message(client,userdata,message):
    client._queue.put((message.payload,message.topic))


def check_time(fake_client,message,datatype):
    try:
        temp=loads(message)
        if fake_client.begin_time or fake_client.end_time and 'T' in temp:
            now_=datetime.datetime.fromtimestamp(temp['T'],tz=datetime.timezone.utc)
            for i,b in enumerate(fake_client.begin_time):
                if b and now_.astimezone(b.tzinfo).time().replace(tzinfo=b.tzinfo)<b:
                    continue

                if fake_client.end_time[i]\
                    and now_.astimezone(fake_client.end_time[i].tzinfo).time().replace(tzinfo=fake_client.end_time[i].tzinfo)>fake_client.end_time[i]:
                    continue

                fake_client._external_on_message(fake_client,message,datatype)
                break

        else:
            fake_client._external_on_message(fake_client,message,datatype)

    except:
        fake_client._external_on_message(fake_client,message,datatype)


def basic_on_publish(client,userdata,mid):
    if mid in client._published:
        del client._published[mid]
        if client._logger:
            if client._published:
                client._logger.info(f'Queueing message:{client._published}')
            else:
                client._logger.info('No queueing message')


def on_publish(client,userdata,mid):
    client._external_on_publish(client,userdata,mid)
    basic_on_publish(client,userdata,mid)


def intervals_process(intervals):
    begin_time=[]
    end_time=[]
    if isinstance(intervals,dict):
        intervals_process_ind(intervals,begin_time,end_time)

    else:
        for interval in intervals:
            intervals_process_ind(interval,begin_time,end_time)

    tz=datetime.timezone(datetime.timedelta(seconds=-time.timezone))
    for i,b in enumerate(begin_time):
        if b and not b.tzinfo:
            begin_time[i]=b.replace(tzinfo=tz)
        if end_time[i] and not end_time[i].tzinfo:
            end_time[i]=end_time[i].replace(tzinfo=tz)

    return begin_time,end_time


def intervals_process_ind(interval,begin_time,end_time):
    temp=tuple(interval.keys())
    for key in temp:
        interval[key.lower()]=interval.pop(key)
    begin_time.append(interval.get('begin'))
    end_time.append(interval.get('end'))
    if begin_time[-1] and end_time[-1] and begin_time[-1]>end_time[-1]:
        raise ValueError('時間設定錯誤，結束時間大於起始時間')


def TopicGenerator(Topics):
    if 'BACK_TEST' in os.environ:
        for t in Topics:
            yield f'{t}/backtest',2
    else:
        for t in Topics:
            yield t,2


def Modify_Subscription(client,userdata,message):
    if message.payload:
        print(f'message.payload={message.payload}')
        payload=eval(message.payload)
        print(f'eval(message.payload)={eval(message.payload)}')
        temp=tuple(client._subscribed.items())
        print(f'tuple(client._subscribed.items())={tuple(client._subscribed.items())}')
        for mid,subscribed in temp:
            unsubscribe_mid=client.unsubscribe(eval(subscribed))[1]
            print(f'client.unsubscribe(eval(subscribed))[1]={unsubscribe_mid}')
            client._unsubscribed[unsubscribe_mid]=subscribed
            client._unsubscribe_subscribe_mid[unsubscribe_mid]=mid

        print(f'list(TopicGenerator(payload))={list(TopicGenerator(payload))}')
        client._subscribed[client.subscribe(list(TopicGenerator(payload)))[1]]=message.payload.decode()


def Modify_UpdateUserData(client,userdata,message):
    if message.payload:
        payload=loads(message.payload)
        if client._lock:
            client._lock.acquire()
        client._userdata.update(payload)
        if client._lock:
            client._lock.release()
        if client._logger:
            client._logger.info(f'Updated userdata:\n{payload}')


def Modify_ModifyUserData(client,userdata,message):
    if message.payload:
        try:
            client._userdata=eval(message.payload)
        except:
            client._userdata=message.payload
        if client._logger:
            client._logger.info(f'Modified userdata:\n{client._userdata}')


def Terminate(client,userdata,message):
    client.disconnect()
    if client._logger:
        client._logger.info(f'Terminated:{time.time()}')


def PingPong(client,userdata,message):
    client.publish(f'{message.topic}/r',True,qos=2)