from importlib import import_module
import os
import pathlib
from mqtt_client import *
from json import load


if __name__=='__main__':
    folders=set(('logs','__pycache__'))
    path=pathlib.Path(__file__).parent
    for reference in os.listdir(path):
        if '__main__' not in reference and reference[-3:]=='.py':
            strategy=import_module(reference.replace('.py',''))
            break

    with open(os.path.join(path,'variables.json')) as f:
        try:
            variables=load(f)
        except:
            variables={}

    for key,value in variables.items():
        variables[key]=value.get('value')
            
    client=internal_StrategyClient(
        ClientId=f'Strategy-{path.name.upper()}',
        Strategy=strategy.Strategy,
        DataProcess=getattr(strategy,'DataProcess',None),
        Emergency=getattr(strategy,'Emergency',None),
        Topics=strategy.Topics,
        Path=path,
        Variables=variables,
        QueueSizeThreshold=getattr(strategy,'Threshold',None)
        )
        
    client.run_strategy(client,getattr(strategy,'Interval',{}))