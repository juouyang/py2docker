from ..external.Client import *


def _on_message_settings(ClientId,Path,intervals,Strategy,Variables):
    fake_client=on_message_settings(ClientId,Path,intervals,Strategy,Variables)[0]
    publisher=mqttclient(client_id=f'{ClientId}_publisher')
    publisher.connect()
    publisher.loop_start()
    
    return fake_client,publisher,1


def _on_message_loop(fake_client,message,datatype,publisher):
    check_time(fake_client,message,datatype)
    if fake_client.signal:
        publisher.SendSignal(fake_client.signal)
        fake_client.StrategyLogger.info(f"Sending signal to {fake_client.ClientId}:\n{fake_client.signal}")
        fake_client.signal=[]
    

def _threshold_check(queue,qsize,QueueSizeThreshold,fake_client):
    temp=queue.qsize()
    if qsize>QueueSizeThreshold and temp>qsize:
        fake_client.StrategyLogger.warning(f'warning: the message queue={temp} which is become longer and longer')
    qsize=temp


def _looping_with_data_process_without_threshold(userdata,indicator_path,queue,DataProcess,fake_client,publisher,Emergency,lock):
    message,datatype=queue.get()
    lock.acquire()
    fake_client.userdata=dict(userdata)
    lock.release()
    if datatype[:10]=='Emergency/' and Emergency:
        Emergency(fake_client,message,datatype)
    indicators=DataProcess(fake_client,message,datatype)
    if indicators:
        indicators['T']=message['T']
        with open(indicator_path,'a',newline='') as f:
            csv.writer(f).writerow([indicators])
    _on_message_loop(fake_client,message,datatype,publisher)
    lock.acquire()
    temp=userdata.items()
    for key,value in temp:
        if key not in fake_client.userdata:
            del userdata[key]
    userdata.update(fake_client.userdata)
    lock.release()


def _looping_with_data_process_with_threshold(userdata,indicator_path,queue,DataProcess,fake_client,publisher,qsize,Emergency,lock,QueueSizeThreshold):
    _looping_with_data_process_without_threshold(userdata,indicator_path,queue,DataProcess,fake_client,publisher,Emergency,lock)
    _threshold_check(queue,qsize,QueueSizeThreshold,fake_client)


def _on_message_with_data_process(userdata,queue,intervals,Topics,ClientId,Path,Strategy,Variables,DataProcess,Emergency,lock,QueueSizeThreshold):
    fake_client,publisher,qsize=_on_message_settings(ClientId,Path,intervals,Strategy,Variables)
    Topics=str(tuple(Topics)).replace('/','_').replace('"',"'")
    Path=os.path.join(Path,'output')
    if not os.path.exists(Path):
        os.mkdir(Path)
    indicator_path=os.path.join(Path,f"indicators{Topics}.csv")
    try:
        os.remove(indicator_path)
    except:
        pass
    if QueueSizeThreshold is None:
        while True:
            _looping_with_data_process_without_threshold(userdata,indicator_path,queue,DataProcess,fake_client,publisher,Emergency,lock)
    else:
        while True:
            _looping_with_data_process_with_threshold(userdata,indicator_path,queue,DataProcess,fake_client,publisher,qsize,Emergency,lock,QueueSizeThreshold)
        

def _looping_without_data_process_without_threshold(userdata,queue,fake_client,publisher,Emergency,lock):
    message,datatype=queue.get()
    lock.acquire()
    fake_client.userdata=dict(userdata)
    lock.release()
    if datatype[:10]=='Emergency/' and Emergency:
        Emergency(fake_client,message,datatype)
    _on_message_loop(fake_client,message,datatype,publisher)
    lock.acquire()
    temp=userdata.items()
    for key,value in temp:
        if key not in fake_client.userdata:
            del userdata[key]
    userdata.update(fake_client.userdata)
    lock.release()
    

def _looping_without_data_process_with_threshold(userdata,queue,fake_client,publisher,qsize,Emergency,lock,QueueSizeThreshold):
    _looping_without_data_process_without_threshold(userdata,queue,fake_client,publisher,Emergency,lock)
    _threshold_check(queue,qsize,QueueSizeThreshold,fake_client)


def _on_message_without_data_process(userdata,queue,intervals,ClientId,Path,Strategy,Variables,Emergency,lock,QueueSizeThreshold):
    fake_client,publisher,qsize=_on_message_settings(ClientId,Path,intervals,Strategy,Variables)
    if QueueSizeThreshold is None:
        while True:
            _looping_without_data_process_without_threshold(userdata,queue,fake_client,publisher,Emergency,lock)
    else:
        while True:
            _looping_without_data_process_with_threshold(userdata,queue,fake_client,publisher,qsize,Emergency,lock,QueueSizeThreshold)

        
def _run_strategy(self,intervals={}):
    if self._state==mqtt.mqtt_cs_connect_async:
        self._reconnect_wait()
        self.reconnect()
    else:
        self.connect()

    self.on_message=on_message

    if self.on_publish is None:
        self.on_publish=basic_on_publish
    else:
        self._external_on_publish=self.on_publish
        self.on_publish=on_publish

    if self._DataProcess:
        Process(
            target=_on_message_with_data_process,
            args=(
                self._userdata,
                self._queue,
                intervals,
                self._Topics,
                self._client_id.decode(),
                self._Path,
                self._Strategy,
                self._Variables,
                self._DataProcess,
                self._Emergency,
                self._lock,
                self._QueueSizeThreshold
                )
                ).start()
        
    else:
        Process(
            target=_on_message_without_data_process,
            args=(
                self._userdata,
                self._queue,
                intervals,
                self._client_id.decode(),
                self._Path,
                self._Strategy,
                self._Variables,
                self._Emergency,
                self._lock,
                self._QueueSizeThreshold
                )
                ).start()
        
    self.loop_forever()


def internal_StrategyClient(ClientId,Path,Strategy,Topics,Variables,QueueSizeThreshold,DataProcess=None,Emergency=None):
    client=external_StrategyClient(ClientId,Path,Strategy,Topics,Variables,DataProcess,Emergency)
    client.run_strategy=_run_strategy
    client._QueueSizeThreshold=QueueSizeThreshold

    return client
