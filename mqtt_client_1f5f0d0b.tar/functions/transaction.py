import datetime
import numpy as np
from decimal import Decimal


def Judgements(signal,now_,payload):
    if 'Validity' not in signal\
        or (isinstance(signal['Validity'],str) and datetime.datetime.fromisoformat(signal['Validity']).timestamp()>now_)\
        or (isinstance(signal['Validity'],float) and signal['Validity']>now_):
        
        if signal['Trend']:
            if payload.get('A'):
                if isinstance(payload['A'],dict):
                    price=np.array(tuple(payload['A'].keys()),dtype=float).min()
                else:
                    price=payload['A']
            else:
                price=payload['P']
        else:
            if payload.get('B'):
                if isinstance(payload['B'],dict):
                    price=np.array(tuple(payload['B'].keys()),dtype=float).max()
                else:
                    price=payload['B']
            else:
                price=payload['P']

        if not signal.get('Price') or signal['Price']*(2*signal['Trend']-1)>=price*(2*signal['Trend']-1):
            return price
        else:
            return False


def GetInventories(inventories,signal,symbol,sid,price):
    ret={'Position':signal['Position'],'Action':signal['Trend'],'Symbol':symbol,'StrategyID':sid,'Price':price}
    price=Decimal(str(price))
    if symbol in inventories:
        if sid in inventories[symbol]:
            if signal['Position']:
                if signal['Trend'] in inventories[symbol][sid]:
                    inventories[symbol][sid][signal['Trend']].append([price,Decimal.from_float(signal['Quantity'])])
                else:
                    inventories[symbol][sid][signal['Trend']]=[[price,Decimal.from_float(signal['Quantity'])]]
                print(f"{sid}-opened:{price,Decimal.from_float(signal['Quantity'])}")
                ret.update({'Volume':signal['Quantity']})

            elif inventories[symbol][sid].get(not signal['Trend']):
                left=Decimal(str(np.array(inventories[symbol][sid][not signal['Trend']]).sum(axis=0)[1]**signal['Proportion']))
                temp=left
                realized_value=Decimal('0')
                realized_volume=Decimal('0')
                i=0
                while i<len(inventories[symbol][sid][not signal['Trend']]):
                    if inventories[symbol][sid][not signal['Trend']][i][1]>left:
                        inventories[symbol][sid][not signal['Trend']][i][1]-=left
                        realized_volume+=left
                        realized_value+=inventories[symbol][sid][not signal['Trend']][i][0]*left
                    else:
                        left-=inventories[symbol][sid][not signal['Trend']][i][1]
                        realized_volume+=inventories[symbol][sid][not signal['Trend']][i][1]
                        realized_value+=inventories[symbol][sid][not signal['Trend']][i][0]*inventories[symbol][sid][not signal['Trend']][i][1]
                        del inventories[symbol][sid][not signal['Trend']][i]

                print(f'{sid}-closed:{price,realized_volume}')
                ret.update({'Volume':realized_volume,'Profit':(realized_volume*price-realized_value)*(-2*signal['Trend']+1)})
                
        elif signal['Position']:
            inventories[symbol][sid]={
                signal['Trend']:[[price,Decimal.from_float(signal['Quantity'])]]
                }
            print(f"{sid}-opened:{price,Decimal.from_float(signal['Quantity'])}")
            ret.update({'Volume':signal['Quantity']})

    elif signal['Position']:
        inventories[symbol]={
            sid:{
                signal['Trend']:[[price,Decimal.from_float(signal['Quantity'])]]
                }}
        print(f"{sid}-opened:{price,Decimal.from_float(signal['Quantity'])}")
        ret.update({'Volume':signal['Quantity']})
        
    for key,value in ret.items():
        if isinstance(value,Decimal):
            ret[key]=str(value)

    return ret