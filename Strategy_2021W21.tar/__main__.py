from importlib import import_module
import os
import pathlib
from mqtt_client import Client

if __name__=='__main__':
    folders=set(('logs','__pycache__'))
    path=pathlib.Path(__file__).parent
    for reference in os.listdir(path):
        if '__main__' not in reference and reference[-3:]=='.py':
            strategy=import_module(reference.replace('.py',''))
            break
            
    client=Client(
        ClientId=f'Strategy-{path.name.upper()}',
        Strategy=strategy.Strategy,
        DataProcess=getattr(strategy,'DataProcess',None),
        Emergency=getattr(strategy,'Emergency',None),
        Topics=strategy.Topics,
        UserData=getattr(strategy,'UserData',None),
        Path=path
        )
    
    client.run(getattr(strategy,'Interval',{}))