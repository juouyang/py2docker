import enum

class Tick(enum.IntEnum):
    #Tick在中斷過後恢復
    TickRecovered=0
    #Tick中斷中
    TickSuspend=1