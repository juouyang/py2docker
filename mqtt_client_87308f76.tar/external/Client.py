import csv
from multiprocessing import Manager, Process, Queue, RLock

import pandas as pd
from ..mqtt_client import *

from ..functions.transaction import *


def _on_message_loop(fake_client,message,datatype,signals,inventories,record_path):
    check_time(fake_client,message,datatype)
    message=loads(message)
    if fake_client.signal:
        signals.extend(fake_client.signal)
        fake_client.signal=[]
    i=0
    while i<len(signals):
        if signals[i]['Symbol'] in datatype:
            price=Judgements(signals[i],message['T'],message)
            if price:
                result=GetInventories(inventories,signals[i],datatype.split('/')[0],fake_client.ClientId.replace('Strategy-',''),price)
                del signals[i]
                result['T']=message['T']
                with open(record_path,'a',newline='') as f:
                    csv.writer(f).writerow([result])

            elif price is False:
                i+=1

            else:
                del signals[i]


def _on_message_with_data_process(userdata,queue,intervals,Topics,ClientId,Path,Strategy,Variables,DataProcess,Emergency,lock):
    fake_client,inventories,signals=on_message_settings(ClientId,Path,intervals,Strategy,Variables)
    Topics=str(tuple(Topics)).replace('/','_').replace('"',"'")
    Path=os.path.join(Path,'output')
    if not os.path.exists(Path):
        os.mkdir(Path)
    indicator_path=os.path.join(Path,f'indicators_{Topics}.csv')
    try:
        os.remove(indicator_path)
    except:
        pass
    record_path=os.path.join(Path,f'records_{Topics}.csv')
    try:
        os.remove(record_path)
    except:
        pass
    while True:
        message,datatype=queue.get()
        lock.acquire()
        fake_client.userdata=dict(userdata)
        lock.release()
        if datatype[:10]=='Emergency/' and Emergency:
            Emergency(fake_client,message,datatype)
        indicators=DataProcess(fake_client,message,datatype)
        if indicators:
            indicators['T']=message['T']
            with open(indicator_path,'a',newline='') as f:
                csv.writer(f).writerow([indicators])
        _on_message_loop(fake_client,message,datatype,signals,inventories,record_path)
        lock.acquire()
        userdata=Manager().dict(fake_client.userdata)
        lock.release()
        

def _on_message_without_data_process(userdata,queue,intervals,Topics,ClientId,Path,Strategy,Variables,Emergency,lock):
    fake_client,inventories,signals=on_message_settings(ClientId,Path,intervals,Strategy,Variables)
    if not os.path.exists(os.path.join(Path,'output')):#python 3.7
        os.mkdir(os.path.join(Path,'output'))

    Path=os.path.join(Path,'output')
    record_path=os.path.join(Path,f'records_{Topics}.csv')
    try:
        os.remove(record_path)
    except:
        pass
    while True:
        message,datatype=queue.get()
        lock.acquire()
        fake_client.userdata=dict(userdata)
        lock.release()
        if datatype[:10]=='Emergency/' and Emergency:
            Emergency(fake_client,message,datatype)
        
        _on_message_loop(fake_client,message,datatype,signals,inventories,record_path)
        lock.acquire()
        temp=userdata.items()
        for key,value in temp:
            if key not in fake_client.userdata:
                del userdata[key]
        userdata.update(fake_client.userdata)
        lock.release()
        

def run_strategy(self,intervals={}):
    if self._state==mqtt.mqtt_cs_connect_async:
        self._reconnect_wait()
        self.reconnect()
    else:
        self.connect()

    self.on_message=on_message

    if self.on_publish is None:
        self.on_publish=basic_on_publish
    else:
        self._external_on_publish=self.on_publish
        self.on_publish=on_publish

    if self._DataProcess:
        Process(
            target=_on_message_with_data_process,
            args=(
                self._userdata,
                self._queue,
                intervals,
                self._Topics,
                self._client_id.decode(),
                self._Path,
                self._Strategy,
                self._Variables,
                self._DataProcess,
                self._Emergency,
                self._lock,
                )
                ).start()
        
    else:
        Process(
            target=_on_message_without_data_process,
            args=(
                self._userdata,
                self._queue,
                intervals,
                self._Topics,
                self._client_id.decode(),
                self._Path,
                self._Strategy,
                self._Variables,
                self._Emergency,
                self._lock,
                )
                ).start()
        
    self.loop_forever()


def external_StrategyClient(ClientId,Path,Strategy,Topics,Variables,DataProcess=None,Emergency=None):
    client=mqttclient(client_id=ClientId,userdata=Manager().dict())
    client.run_strategy=run_strategy
    client._queue=Queue()
    client._Strategy=Strategy
    client._lock=RLock()
    folders=set(('logs','__pycache__','output'))
    for reference in os.listdir(Path):
        if reference not in folders and '.' not in reference:
            break
    TDQSymbol=set(pd.read_csv(os.path.join(Path,reference,'TDQSymbol.csv'))['ISIN'])
    for topic in Topics:
        row=None
        for ISIN in topic.split('/'):
            if ISIN in TDQSymbol:
                row=True
                break
        if row is None:
            continue
            #raise ValueError(f'topic:{topic}，DB內無此ISIN，請檢查Topics')

    client._DataProcess=DataProcess
    client._Emergency=Emergency
    client._Variables=Variables

    return client_settings(client,Topics,Path)
