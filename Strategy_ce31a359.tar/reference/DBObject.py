def get_engine():
    import sqlalchemy
    from . import DBConfig
    return sqlalchemy.create_engine(
        f'mssql+pyodbc://{DBConfig.USERNAME}:{DBConfig.PASSWORD}@{DBConfig.HOST}:{DBConfig.PORT}/Doquant?driver=ODBC Driver 17 for SQL Server')