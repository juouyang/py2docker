def payload_process(payload,SID):
    payload['Position']=bool(payload['Position'])

    if payload['Trend']>0:
        payload['Trend']=True
    else:
        payload['Trend']=False

    if 'Daily' in payload:
        if isinstance(payload['Daily'],str):
            if 'y' in payload['Daily'].lower():
                payload['Daily']=True
            elif 'n' in payload['Daily'].lower():
                payload['Daily']=False
            else:
                del payload['Daily']

    payload['SID']=SID